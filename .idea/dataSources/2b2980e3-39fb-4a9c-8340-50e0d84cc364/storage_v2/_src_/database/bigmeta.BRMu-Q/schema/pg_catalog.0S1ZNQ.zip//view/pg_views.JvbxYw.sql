create view pg_views(schemaname, viewname, viewowner, definition) as
SELECT n.nspname                   AS schemaname,
       c.relname                   AS viewname,
       pg_get_userbyid(c.relowner) AS viewowner,
       pg_get_viewdef(c.oid)       AS definition
FROM pg_class c
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = 'v'::"char";

alter table pg_views
    owner to aloudata;

grant select on pg_views to public;

